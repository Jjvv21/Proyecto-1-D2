//
// Created by andres on 16/03/18.
//

#ifndef WINDOW_H
#define WINDOW_H

#include <QKeyEvent>
#include <QWidget>
#include <QtWidgets/QLabel>
#include <QtWidgets/QScrollArea>
#include <QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtCore/QCoreApplication>
#include <QtGui/QTextBlock>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QListView>


using namespace std;
/**
 * @brief The Window class : Clase que corresponde a la ventana principal
 */
class Window : public QWidget {
Q_OBJECT
public:

    explicit Window(QWidget *parent = 0);

    QString getEditorReading();

    void RefreshRAMBox();
private slots:

        void RunProgram();

        void StopProgram();

        void NextLine();
private:

    QPushButton *NextLineButton;

    QPushButton *RunButton;

    QPushButton *StopButton;

    QTableWidget *Table;

    QListView *Log1;

    QListView *Log2;

    QTableWidgetItem *Header1, *Header2, *Header3, *Header4;

    QTextEdit *Code;

};

#endif // WINDOW_H