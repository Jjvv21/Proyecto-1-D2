#include <QApplication>
#include <QPushButton>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QTextEdit>
#include <QGroupBox>
#include <QTableWidget>
#include <iostream>
#include "Window.h"


Window::Window(QWidget *parent) :
        QWidget(parent) {
    setFixedSize(900, 650);
    this->setWindowTitle("C! IDE");
    QGridLayout *layout = new QGridLayout(this);
    this->setLayout(layout);
    /***
     * @Widget
     * Estos son los botones que se utilizaran en el IDE
     */
     //BOTON PARA EJECUTAR EL CODIGO
    RunButton = new QPushButton("▶",this);
    RunButton->setFixedSize(30,30);
    connect(RunButton,SIGNAL(clicked()),this,SLOT(RunProgram()));
    //BOTON PARA DETENER EL FLUJO DEL PROGRAMA
    StopButton = new QPushButton("▪",this);
    StopButton->setFixedSize(32,32);
    connect(StopButton,SIGNAL(clicked()),this,SLOT(StopProgram()));
    //BOTON PARA SALTAR LINEA
    NextLineButton = new QPushButton("▼",this);
    NextLineButton->setFixedSize(30,30);
    connect(NextLineButton,SIGNAL(clicked()),this,SLOT(NextLine()));
    /***
     * @Layout
     * LayOut para los botones
     */
    layout->addWidget(NextLineButton,0,1);
    layout->addWidget(RunButton, 0, 0);
    layout->addWidget(StopButton, 0, 2);
    /***
     * @Widget
     * Este es un grupo en el que se crea dentro una contenedora para el TextEdit
     */
    QGroupBox *box = new QGroupBox("Code C!:", this);
    QVBoxLayout *boxLayout = new QVBoxLayout(box);
    QWidget* CodeWindow = new QWidget(box);
    CodeWindow->setFixedHeight(400);
    boxLayout->addWidget(CodeWindow);
    layout->addWidget(box, 1, 2);
    /***
     * @Widget
     * Esta es la tabla con las columnas para el RAM LIVE VIEW
     */
    Table = new QTableWidget(this);
    Table->setFixedSize(200,500);
    Table->setColumnCount(4);
    /***
     * @Headers
     * Estas son las cabeceras para cada columna
     */
    Header1 = new QTableWidgetItem();
    Header2 = new QTableWidgetItem();
    Header3 = new QTableWidgetItem();
    Header4 = new QTableWidgetItem();
    Header1->setText("Valor");
    Header2->setText("Direccion");
    Header3->setText("Conteo");
    Header4->setText("Etiqueta");
    Table->setHorizontalHeaderItem(0,Header1);
    Table->setHorizontalHeaderItem(1,Header2);
    Table->setHorizontalHeaderItem(2,Header3);
    Table->setHorizontalHeaderItem(3,Header4);
    layout->addWidget(Table,1,3);

    QGroupBox *LogBox = new QGroupBox("Registro de consola", this);
    QVBoxLayout *LogLayout = new QVBoxLayout(LogBox);
    QWidget* LogWindow = new QWidget(LogBox);
    CodeWindow->setFixedHeight(350);
    LogLayout->addWidget(LogWindow);
    layout->addWidget(LogBox, 2, 2);

    QHBoxLayout *nameLayout = new QHBoxLayout(CodeWindow);
    Code = new QTextEdit();
    Code->setFont(
            QFont ("Ubuntu Mono", 12)
            );
    nameLayout->addWidget(Code);


    QHBoxLayout *BoxLogLayout = new QHBoxLayout(LogWindow);
    QTabWidget *TabWindow = new QTabWidget();
    BoxLogLayout->addWidget(TabWindow);
    Log1 = new QListView(this);
    Log1->setFixedHeight(100);
    Log2 = new QListView(this);
    Log2->setFixedHeight(100);
    TabWindow->addTab(Log1, tr("Stdout"));
    TabWindow->addTab(Log2, tr("Application Log"));
}
void Window::RunProgram(){
    QString data = Window::Code->toPlainText();
    const QString &s = data;
    qDebug("%s", qPrintable(s));
}
void Window::StopProgram() {
    std::cout<<"Stop";
}
void Window::NextLine() {
    std::cout<<"Siguiente";
}


